package client;

import client.Client;

public class Main {

	public static void main(String[] args) {

		new Client();

	}
}